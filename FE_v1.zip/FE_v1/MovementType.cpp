#include "MovementType.h"

MovementType::MovementType(int movementRange) {
	this->movementRange = movementRange;
}

int MovementType::costeMovimiento(Tile* tile) {
	cout << "que cojones" << endl;
	return 0;
}
