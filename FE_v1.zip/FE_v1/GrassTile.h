#pragma once

#include "Tile.h"

class GrassTile : public Tile {
public:
	GrassTile(float x, float y, Game* game);
};

