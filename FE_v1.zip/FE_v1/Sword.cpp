#include "Sword.h"

Sword::Sword()
	: WeaponType() {

}