#pragma once

#include "Tile.h"

class ForestTile : public Tile {
public:
	ForestTile(float x, float y, Game* game);
};