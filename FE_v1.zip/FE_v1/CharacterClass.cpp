#include "CharacterClass.h"

CharacterClass::CharacterClass(WeaponType* weaponType, MovementType* movementType) {
	this->weaponType = weaponType;
	this->movementType = movementType;
}