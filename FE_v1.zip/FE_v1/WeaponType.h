#pragma once

class WeaponType {
public:
	
};