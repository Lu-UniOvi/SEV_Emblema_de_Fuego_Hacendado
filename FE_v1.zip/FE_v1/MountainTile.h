#pragma once

#include "Tile.h"

class MountainTile : public Tile {
public:
	MountainTile(float x, float y, Game* game);
};