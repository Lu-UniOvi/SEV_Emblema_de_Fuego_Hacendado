#pragma once

#include "CharacterClass.h"
#include "Sword.h"
#include "Infantry.h"

class Princess : public CharacterClass {
public:
	Princess();
};