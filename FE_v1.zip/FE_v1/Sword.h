#pragma once

#include "WeaponType.h"

class Sword : public WeaponType {
public:
	Sword();
};